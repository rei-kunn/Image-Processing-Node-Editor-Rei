##########################################################
# Dear PyGui User Interface - Experimental
##########################################################

import dearpygui.dearpygui as dpg
import dearpygui._dearpygui as internal_dpg

def test_function():
	print("test function ran")
